package com.example.myapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextBinary;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextBinary = findViewById(R.id.editTextBinary);
        textViewResult = findViewById(R.id.textViewResult);
        Button buttonConvert = findViewById(R.id.buttonConvert);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertBinaryToDecimal();
            }
        });
    }

    private void convertBinaryToDecimal() {
        String binaryString = editTextBinary.getText().toString().trim();


        if (TextUtils.isEmpty(binaryString)) {
            Toast.makeText(this, "Por favor, insira um número binário", Toast.LENGTH_SHORT).show();
            return;
        }


        if (!binaryString.matches("[01]+")) {
            Toast.makeText(this, "O número deve conter apenas dígitos 0 ou 1", Toast.LENGTH_SHORT).show();
            return;
        }

        int decimalValue = 0;
        int length = binaryString.length();


        for (int i = 0; i < length; i++) {

            char binaryDigit = binaryString.charAt(i);
            int bit = Character.getNumericValue(binaryDigit);
            int power = length - i - 1;
            decimalValue += bit * Math.pow(2, power);
        }


        textViewResult.setText("Resultado: " + decimalValue);
    }
}
