package com.example.consolesantigos;

public class ConsolesAntigos {
    private String nome;
    private int lancamento;
    private String publicadora;
    private String historia;

    public ConsolesAntigos(String nome, int lancamento, String publicadora, String historia) {
        this.nome = nome;
        this.lancamento = lancamento;
        this.publicadora = publicadora;
        this.historia = historia;
    }

    public String getNome() {
        return nome;
    }

    public int getLancamento() {
        return lancamento;
    }

    public String getPublicadora() {
        return publicadora;
    }

    public String getHistoria() {
        return historia;
    }
}
