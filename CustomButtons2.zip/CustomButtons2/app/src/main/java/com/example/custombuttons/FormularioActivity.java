package com.example.custombuttons;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FormularioActivity extends AppCompatActivity {
    private EditText nomeText, senhaOriginal, senhaValidador;
    private Button botaoEnviar;
    private TextView textoExibir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        nomeText = findViewById(R.id.nomeText);
        senhaOriginal = findViewById(R.id.senhaOriginal);
        senhaValidador = findViewById(R.id.senhaValidador);
        botaoEnviar = findViewById(R.id.botaoEnviar);
        textoExibir = findViewById(R.id.textoExibir);

        botaoEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String senha = senhaOriginal.getText().toString();
                String validarSenha = senhaValidador.getText().toString();

                if (senha.equals(validarSenha)){
                    textoExibir.setText("Senha válida");
                } else {
                    textoExibir.setText("Senha inválidas");
                }
                textoExibir.setVisibility(View.VISIBLE);
            }
        });
    }
}