
package com.example.appjuros;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.appjuros.R;

public class MainActivity extends AppCompatActivity {

    private EditText editTextValorInicial;
    private EditText editTextTaxaJuros;
    private EditText editTextAnos;
    private TextView textViewResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextValorInicial = findViewById(R.id.editTextValorInicial);
        editTextTaxaJuros = findViewById(R.id.editTextTaxaJuros);
        editTextAnos = findViewById(R.id.editTextAnos);
        textViewResultado = findViewById(R.id.textViewResultado);
        Button buttonCalcular = findViewById(R.id.buttonCalcular);

        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularRendimento();
            }
        });
    }

    private void calcularRendimento() {

        if (TextUtils.isEmpty((CharSequence) editTextValorInicial)) {
            Toast.makeText(this, "Por favor, insira um número binário", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty((CharSequence) editTextTaxaJuros)) {
            Toast.makeText(this, "Por favor, insira um número binário", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty((CharSequence) editTextAnos)) {
            Toast.makeText(this, "Por favor, insira um número binário", Toast.LENGTH_SHORT).show();
            return;
        }


        double valorInicial = Double.parseDouble(editTextValorInicial.getText().toString());
        double taxaJuros = Double.parseDouble(editTextTaxaJuros.getText().toString()) / 100;
        int anos = Integer.parseInt(editTextAnos.getText().toString());


        double valorFinal = valorInicial * Math.pow(1 + taxaJuros, anos);

        textViewResultado.setText(String.format("Resultado: R$ %.2f", valorFinal));
    }
}
