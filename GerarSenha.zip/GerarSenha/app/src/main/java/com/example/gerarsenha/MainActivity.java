package com.example.gerarsenha;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView textViewSenha;
    private Button buttonGerarSenha;

    private String letrasMinusculas = "abcdefghijklmnopqrstuvwxyz";
    private String numeros = "0123456789";
    private String simbolos = "!@#$%&";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewSenha = findViewById(R.id.textViewSenha);
        buttonGerarSenha = findViewById(R.id.buttonGerarSenha);

        buttonGerarSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String senha = gerarSenha();
                textViewSenha.setText(senha);
            }
        });
    }

    private String gerarSenha() {
        StringBuilder senha = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 3; i++) {
            char letra = letrasMinusculas.charAt(random.nextInt(letrasMinusculas.length()));
            senha.append(letra);

            char numero = numeros.charAt(random.nextInt(numeros.length()));
            senha.append(numero);

            char simbolo = simbolos.charAt(random.nextInt(simbolos.length()));
            senha.append(simbolo);
        }

        return senha.toString();
    }
}
