package com.example.jokenpo

import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Random

class MainActivity : AppCompatActivity() {
    private var ringueIAPapel: ImageView? = null
    private var ringueIAPedra: ImageView? = null
    private var ringueIATesoura: ImageView? = null
    private var ringueJogadorPapel: ImageView? = null
    private var ringueJogadorPedra: ImageView? = null
    private var ringueJogadorTesoura: ImageView? = null
    private var circuloAzul: ImageView? = null
    private var circuloVermelho: ImageView? = null
    private var vitoriaJogador01: TextView? = null
    private var vitoriaJogador02: TextView? = null
    private var vitoriaJogador03: TextView? = null
    private var nomeJogador: TextView? = null
    private var vitoriaIA01: TextView? = null
    private var vitoriaIA02: TextView? = null
    private var vitoriaIA03: TextView? = null
    private var nomeIA: TextView? = null
    private var versus: TextView? = null

    private var vencedor: ImageView? = null
    private var perdedor: ImageView? = null

    private var jogadorVenceu = 0
    private var iaVenceu = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // referenciando as views
        ringueIAPapel = findViewById(R.id.ringueIAPapel)
        ringueIAPedra = findViewById(R.id.ringueIAPedra)
        ringueIATesoura = findViewById(R.id.ringueIATesoura)

        ringueJogadorPapel = findViewById(R.id.ringueJogadorPapel)
        ringueJogadorPedra = findViewById(R.id.ringueJogadorPedra)
        ringueJogadorTesoura = findViewById(R.id.ringueJogadorTesoura)

        vitoriaJogador01 = findViewById(R.id.vitoriaJogador01)
        vitoriaJogador02 = findViewById(R.id.vitoriaJogador02)
        vitoriaJogador03 = findViewById(R.id.vitoriaJogador03)
        nomeJogador = findViewById(R.id.nomeJogador)

        vitoriaIA01 = findViewById(R.id.vitoriaIA01)
        vitoriaIA02 = findViewById(R.id.vitoriaIA02)
        vitoriaIA03 = findViewById(R.id.vitoriaIA03)
        nomeIA = findViewById(R.id.nomeIA)

        versus = findViewById(R.id.versus)

        circuloAzul = findViewById(R.id.circuloAzul)
        circuloVermelho = findViewById(R.id.circuloVermelho)

        vencedor = findViewById(R.id.vencedor)
        perdedor = findViewById(R.id.perdedor)

        // definimos os listener e conforme a escolha, chamamos o método jogar passando por parametro um número correspondente a escolha
        // 0 - papel ... 1 - pedra ... 2 - tesoura
        findViewById<View>(R.id.escolhaJogadorPapel).setOnClickListener { view: View? ->
            jogar(
                0
            )
        }
        findViewById<View>(R.id.escolhaJogadorPedra).setOnClickListener { view: View? ->
            jogar(
                1
            )
        }
        findViewById<View>(R.id.escolhaJogadorTesoura).setOnClickListener { view: View? ->
            jogar(
                2
            )
        }

        // Tornando as imagens invisíveis no início
        resetarVisibilidade()
    }

    private fun jogar(escolhaJogador: Int) {
        resetarVisibilidade()

        // 0 = Papel, 1 = Pedra, 2 = Tesoura
        val escolhaIA = Random().nextInt(3)
        mostrarEscolhaIA(escolhaIA)
        mostrarEscolhaJogador(escolhaJogador)

        // Determina o vencedor da rodada
        if (escolhaJogador == escolhaIA) {
            /*
            como atividade os alunos podem tentar implementar a exibição da palavra empate
            ou então marcar um ponto para cada jogador
            */
        } else if ((escolhaJogador == 0 && escolhaIA == 1) ||  // Papel vence Pedra
            (escolhaJogador == 1 && escolhaIA == 2) ||  // Pedra vence Tesoura
            (escolhaJogador == 2 && escolhaIA == 0)
        ) {  // Tesoura vence Papel
            jogadorVenceu++
            contabilizarVitoriaJogador()
        } else {
            iaVenceu++
            contabilizarVitoriaIA()
        }

        // Verifica se alguém venceu 3 vezes
        verificarVencedor()
    }

    private fun mostrarEscolhaIA(escolha: Int) {
        when (escolha) {
            0 -> ringueIAPapel!!.visibility = View.VISIBLE
            1 -> ringueIAPedra!!.visibility = View.VISIBLE
            2 -> ringueIATesoura!!.visibility = View.VISIBLE
        }
    }

    private fun mostrarEscolhaJogador(escolha: Int) {
        when (escolha) {
            0 -> ringueJogadorPapel!!.visibility = View.VISIBLE
            1 -> ringueJogadorPedra!!.visibility = View.VISIBLE
            2 -> ringueJogadorTesoura!!.visibility = View.VISIBLE
        }
    }

    private fun contabilizarVitoriaJogador() {
        if (jogadorVenceu == 1) {
            vitoriaJogador01!!.visibility = View.VISIBLE
        } else if (jogadorVenceu == 2) {
            vitoriaJogador02!!.visibility = View.VISIBLE
        } else if (jogadorVenceu == 3) {
            vitoriaJogador03!!.visibility = View.VISIBLE
        }
    }

    private fun contabilizarVitoriaIA() {
        if (iaVenceu == 1) {
            vitoriaIA01!!.visibility = View.VISIBLE
        } else if (iaVenceu == 2) {
            vitoriaIA02!!.visibility = View.VISIBLE
        } else if (iaVenceu == 3) {
            vitoriaIA03!!.visibility = View.VISIBLE
        }
    }

    private fun verificarVencedor() {
        if (jogadorVenceu == 3) {
            esconderPlacarERingue()
            vencedor!!.visibility = View.VISIBLE

            // Aguardar 3 segundos e resetar o jogo
            Handler().postDelayed({ resetarJogo() }, 3000) // 3000 milissegundos = 3 segundos
        } else if (iaVenceu == 3) {
            esconderPlacarERingue()
            perdedor!!.visibility = View.VISIBLE

            // Aguardar 3 segundos e resetar o jogo
            Handler().postDelayed({ resetarJogo() }, 3000) // 3000 milissegundos = 3 segundos
        }
    }

    private fun resetarJogo() {
        // Reinicializar os contadores de vitórias
        jogadorVenceu = 0
        iaVenceu = 0

        // Tornar os placares e nomes visíveis novamente
        vitoriaJogador01!!.visibility = View.INVISIBLE
        vitoriaJogador02!!.visibility = View.INVISIBLE
        vitoriaJogador03!!.visibility = View.INVISIBLE
        nomeJogador!!.visibility = View.VISIBLE

        vitoriaIA01!!.visibility = View.INVISIBLE
        vitoriaIA02!!.visibility = View.INVISIBLE
        vitoriaIA03!!.visibility = View.INVISIBLE
        nomeIA!!.visibility = View.VISIBLE

        // Tornar o ringue visível novamente
        circuloAzul!!.visibility = View.VISIBLE
        circuloVermelho!!.visibility = View.VISIBLE
        versus!!.visibility = View.VISIBLE

        // Esconder as imagens de vencedor e perdedor
        vencedor!!.visibility = View.INVISIBLE
        perdedor!!.visibility = View.INVISIBLE
    }

    private fun resetarVisibilidade() {
        ringueIAPapel!!.visibility = View.INVISIBLE
        ringueIAPedra!!.visibility = View.INVISIBLE
        ringueIATesoura!!.visibility = View.INVISIBLE
        ringueJogadorPapel!!.visibility = View.INVISIBLE
        ringueJogadorPedra!!.visibility = View.INVISIBLE
        ringueJogadorTesoura!!.visibility = View.INVISIBLE
        vencedor!!.visibility = View.INVISIBLE
        perdedor!!.visibility = View.INVISIBLE
    }

    private fun esconderPlacarERingue() {
        // Escondendo o placar
        vitoriaJogador01!!.visibility = View.INVISIBLE
        vitoriaJogador02!!.visibility = View.INVISIBLE
        vitoriaJogador03!!.visibility = View.INVISIBLE
        nomeJogador!!.visibility = View.INVISIBLE

        vitoriaIA01!!.visibility = View.INVISIBLE
        vitoriaIA02!!.visibility = View.INVISIBLE
        vitoriaIA03!!.visibility = View.INVISIBLE
        nomeIA!!.visibility = View.INVISIBLE

        // Escondendo o ringue
        ringueIAPapel!!.visibility = View.INVISIBLE
        ringueIAPedra!!.visibility = View.INVISIBLE
        ringueIATesoura!!.visibility = View.INVISIBLE
        ringueJogadorPapel!!.visibility = View.INVISIBLE
        ringueJogadorPedra!!.visibility = View.INVISIBLE
        ringueJogadorTesoura!!.visibility = View.INVISIBLE
        circuloAzul!!.visibility = View.INVISIBLE
        circuloVermelho!!.visibility = View.INVISIBLE
        versus!!.visibility = View.INVISIBLE
    }
}