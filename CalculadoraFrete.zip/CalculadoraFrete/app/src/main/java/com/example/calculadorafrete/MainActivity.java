package com.example.calculadorafrete;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPeso;
    private EditText editTextDistancia;
    private Button buttonCalcular;
    private TextView textViewResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPeso = findViewById(R.id.editTextPeso);
        editTextDistancia = findViewById(R.id.editTextDistancia);
        buttonCalcular = findViewById(R.id.buttonCalcular);
        textViewResultado = findViewById(R.id.textViewResultado);

        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularFrete();
            }
        });
    }

    private void calcularFrete() {
        String pesoStr = editTextPeso.getText().toString();
        String distanciaStr = editTextDistancia.getText().toString();

        if (pesoStr.isEmpty() || distanciaStr.isEmpty()) {
            Toast.makeText(this, "Por favor, insira valores válidos.", Toast.LENGTH_SHORT).show();
            return;
        }

        double peso = Double.parseDouble(pesoStr);
        double distancia = Double.parseDouble(distanciaStr);
        double valorPeso;
        double valorKm;

        if (peso <= 25.0) {
            valorPeso = 2.0;
            valorKm = 1.0;
        } else if (peso <= 50.0) {
            valorPeso = 2.25;
            valorKm = 1.25;
        } else if (peso <= 75.0) {
            valorPeso = 2.5;
            valorKm = 1.5;
        } else {
            valorPeso = 3.0;
            valorKm = 2.0;
        }

        double valorFrete = (distancia * valorKm) + (peso * valorPeso);
        textViewResultado.setText("Valor do frete: R$ " + String.format("%.2f", valorFrete));
    }
}
