package com.example.votacao_kotlin

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import java.util.Random

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val buttonSortear = findViewById<Button>(R.id.button_sortear)
        val textviewModelo = findViewById<TextView>(R.id.textview_modelo)

        val modelos = Modelos()

        buttonSortear.setOnClickListener {
            val modelosCarros: Array<String> = modelos.getModelosCarros()
            val sorteio = Random().nextInt(modelosCarros.size)
            textviewModelo.text = modelosCarros[sorteio]
        }
    }
}