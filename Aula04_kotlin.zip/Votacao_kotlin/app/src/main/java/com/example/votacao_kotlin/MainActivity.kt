package com.example.votacao_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Guarda o estado da tela entre mudança de telas

        super.onCreate(savedInstanceState)

        this.enableEdgeToEdge()

        // Arquivo dentro da pasta res
        setContentView(R.layout.activity_main)

        val button_login = findViewById<Button>(R.id.button_login)
        button_login.setOnClickListener {
            val intent = Intent(
                this@MainActivity,
                MainActivity2::class.java
            )
            startActivity(intent)
        }
    }
}