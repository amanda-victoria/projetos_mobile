public class Candidato implements Votavel {

    private String nome;
    private Partido partido;
    private int numero;
    private int votos;
    private String cargo;

    public Candidato(String nome, Partido partido, int numero, String cargo) {
        this.nome = nome;
        this.partido = partido;
        this.numero = numero;
        this.votos = 0;
        this.cargo = cargo;
    }

    @Override
    public void adicionarVoto() {
        this.votos++;
        if (this.cargo.equals("Vereador")) {
            this.partido.adicionarVoto();
        }
    }

    @Override
    public int getVotos() {
        return this.votos;
    }

    public String getNome() {
        return this.nome;
    }

    public Partido getPartido() {
        return this.partido;
    }

    public int getNumero() {
        return this.numero;
    }

    public String getCargo() {
        return this.cargo;
    }
}
