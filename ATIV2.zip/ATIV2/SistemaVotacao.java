import java.util.ArrayList;
import java.util.List;

public class SistemaVotacao {

    private List<Candidato> candidatos;
    private List<Partido> partidos;

    public SistemaVotacao() {
        this.candidatos = new ArrayList<>();
        this.partidos = new ArrayList<>();
    }

    public void adicionarPartido(Partido partido) {
        this.partidos.add(partido);
    }

    public void adicionarCandidato(Candidato candidato) {
        this.candidatos.add(candidato);
    }

    public Partido buscarPartidoPorNome(String nome) {
        for (Partido partido : partidos) {
            if (partido.getNome().equalsIgnoreCase(nome)) {
                return partido;
            }
        }
        return null;
    }

    public void votar(int numeroPrefeito, int numeroVereador) {
        boolean votoPrefeitoRegistrado = false;
        boolean votoVereadorRegistrado = false;

        for (Candidato candidato : candidatos) {
            if (candidato.getNumero() == numeroPrefeito && candidato.getCargo().equalsIgnoreCase("Prefeito")) {
                candidato.adicionarVoto();
                System.out.println("Voto registrado para prefeito: " + candidato.getNome());
                votoPrefeitoRegistrado = true;
            }
            if (candidato.getNumero() == numeroVereador && candidato.getCargo().equalsIgnoreCase("Vereador")) {
                candidato.adicionarVoto();
                System.out.println("Voto registrado para vereador: " + candidato.getNome());
                votoVereadorRegistrado = true;
            }
        }

        if (!votoPrefeitoRegistrado) {
            System.out.println("Candidato a prefeito não encontrado.");
        }

        if (!votoVereadorRegistrado) {
            System.out.println("Candidato a vereador não encontrado.");
        }
    }

    public void exibirResultados() {
        if (candidatos.isEmpty()) {
            System.out.println("Nenhum candidato registrado.");
            return;
        }

        Candidato vereadorVencedor = null;
        Candidato prefeitoVencedor = null;

        for (Candidato candidato : candidatos) {
            if (candidato.getCargo().equalsIgnoreCase("Vereador")) {
                if (vereadorVencedor == null || candidato.getVotos() > vereadorVencedor.getVotos()) {
                    vereadorVencedor = candidato;
                }
            } else if (candidato.getCargo().equalsIgnoreCase("Prefeito")) {
                if (prefeitoVencedor == null || candidato.getVotos() > prefeitoVencedor.getVotos()) {
                    prefeitoVencedor = candidato;
                }
            }
        }

        System.out.println("Resultados:");
        if (vereadorVencedor != null) {
            System.out.println("Vereador vencedor: " + vereadorVencedor.getNome() + " com " + vereadorVencedor.getVotos() + " votos.");
        } else {
            System.out.println("Nenhum voto registrado para vereador.");
        }

        if (prefeitoVencedor != null) {
            System.out.println("Prefeito vencedor: " + prefeitoVencedor.getNome() + " com " + prefeitoVencedor.getVotos() + " votos.");
        } else {
            System.out.println("Nenhum voto registrado para prefeito.");
        }
    }
}
